# Messaging.OutboundPollResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**to** | **String** | The phone number (recipient) the message was sent to (in E.164 format). | [optional] 
**receivedTimestamp** | **String** | The date and time when the message was recieved by recipient. | [optional] 
**sentTimestamp** | **String** | The date and time when the message was sent. | [optional] 
**status** | **String** | Delivery status of the message | [optional] 


<a name="StatusEnum"></a>
## Enum: StatusEnum


* `PEND` (value: `"PEND"`)

* `SENT` (value: `"SENT"`)

* `DELIVRD` (value: `"DELIVRD"`)

* `EXPIRED` (value: `"EXPIRED"`)

* `DELETED` (value: `"DELETED"`)

* `UNDVBL` (value: `"UNDVBL"`)

* `REJECTED` (value: `"REJECTED"`)

* `READ` (value: `"READ"`)




