# Messaging.InboundPollResponses

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


