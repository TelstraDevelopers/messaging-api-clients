# Messaging.Error

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **Number** | The status code. | [optional] 
**message** | **String** | Message describing the error. | [optional] 


