# Messaging.OutboundPollResponses

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


